# Data

## `brisbane_water_quality.csv`

Water physicochemical parameters and in-situ flow readings from the Brisbane
River water-quality monitoring buoy at the **Colmslie** site, logged every
30 minutes.

- **Source:** Queensland Government Open Data Portal
  <https://www.data.qld.gov.au/dataset/brisbane-river-colmslie-site-water-quality-monitoring-buoy/resource/0ec4dacc-8e78-4c2a-aa70-d7865ec098e2>
- **Coverage in this copy:** 2023-08-04 to 2024-06-27
- **License:** © State of Queensland, provided under the Queensland Government
  Open Data terms of use.

### Columns

| Column | Description |
|---|---|
| `Timestamp` | Local date-time of the reading |
| `Record number` | Sequential logger record ID |
| `Average Water Speed` | Mean water speed over the interval |
| `Average Water Direction` | Mean flow direction (degrees, 0–360) |
| `Chlorophyll` | Chlorophyll concentration (µg/L) |
| `Temperature` | Water temperature (°C) |
| `Dissolved Oxygen` | Dissolved oxygen (mg/L) |
| `Dissolved Oxygen (%Saturation)` | Dissolved oxygen (% saturation) |
| `pH` | pH |
| `Salinity` | Salinity (PSU) |
| `Specific Conductance` | Specific conductance (mS/cm) |
| `Turbidity` | Turbidity (NTU) |
| `<param> [quality]` | Coded quality-assurance flag for each parameter |

The raw file is kept unmodified; all cleaning happens in `src/analysis.py`.
